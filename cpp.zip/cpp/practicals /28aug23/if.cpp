#include<iostream>
int main(){
    int x;
     std::cout<<"enter a num";
        std::cin>>x;
    if(x==69){
        std::cout<<"x is "<<x;
    }}