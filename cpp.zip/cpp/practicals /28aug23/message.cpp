#include<iostream>
using namespace std;
int main(){
    cout<<"\tHello World\n";
}
