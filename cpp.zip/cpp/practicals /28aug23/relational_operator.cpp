#include<iostream>
using namespace std;
int main(){
    int a,b;
    cout<<"enter two nums "; 
        cin>>a>>b;
}