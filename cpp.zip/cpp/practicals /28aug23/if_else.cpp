#include<iostream>

int main(){
    int x,i=1;
     std::cout<<"enter a num";
        std::cin>>x;
    if(x==69){
        std::cout<<"x is "<<x;
    }else{
        std::cout<<"x is different from 69 ";
        
    }}
