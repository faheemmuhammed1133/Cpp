
            k++; // increment k