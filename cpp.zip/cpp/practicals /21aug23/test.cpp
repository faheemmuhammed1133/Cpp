#include <iostream>
// using namespace std;

int main() {
    int a,b;
    
    std::cout << "Hello, World!\n";
   
    std::cout<<"enter value for a & b";
    std::cin>>a>>b;
    
    int sum=a+b;
    std::cout<<"sum of "<<a <<" & "<<b<<" is "<<sum<<"\n";
    return 0;
}