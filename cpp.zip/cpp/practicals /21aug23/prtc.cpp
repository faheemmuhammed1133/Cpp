#include <iostream>
using namespace std;
int main() {
    /*float my_number=15.5;
    cout<<"your number is : "<<my_number<<endl;*/ 
   /* float a,b;
    cout<<"\nenter values for a and b : ";
    cin>>a>>b;
    float c=a+b;
    cout<<"\nthe sum of "<<a<< " & "<<b << " is "<<c;
    if (a>=b){
    float s = (a-b) ;
    cout << "\nthe difference between " <<a<< " & "<<b << " is "<<s;
    }
    else{
    float s = (b-a) ;
    cout << "\nthe difference between the two numbers are:  " <<s;
    }
    float m=a*b;
    cout <<"\nproduct of "<<a<< " & "<<b << " is "<<m;
    if (a>=b){
    float d=(a/b);
    cout<<"\ndivison of "<<a<< " & "<<b << " is "<<d;
    }
    else{
    float d =(b/a);
    cout<<"\ndivison of "<<a<< " & "<<b << " is "<<d<<endl;

    }
    if (a>=b){
        int a,b;
    float f=(a%b);
    cout<<"\nmod of "<<a<< " & "<<b << " is "<<f;
    }
    else{
        int a,b;
    float f=(b%a);
    cout<<"\nmod of "<<a<< " & "<<b << " is "<<f<<endl;
    }*/
    int a,b,operation;
    switch (operation)
    {
    case 4:
        /* code */
        break;
    
    default:
        break;
    }

    return 0;
    }
    