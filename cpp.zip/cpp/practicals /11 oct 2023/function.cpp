#include<iostream>
using namespace std;

void print(string data){
    
    cout<<data<<"\n";
}


int main(){
    print("\nhello!\n");
    print("You are welcome\n");
    print("take a seat\n");
    return 0;
    }