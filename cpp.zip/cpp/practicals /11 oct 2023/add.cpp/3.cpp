// take 3 num subtract
#include<iostream>
using namespace std;
int main(){
    float a,b,c;
    cout<<"enter three numbers to subtract ";
    cin>>a>>b>>c;

    cout<<"substraction of 3 num are : "<<(a-b)-c<<"\n";
}