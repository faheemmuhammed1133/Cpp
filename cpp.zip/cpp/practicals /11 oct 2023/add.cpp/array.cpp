#include<iostream>
using namespace std;
int main(){
    int k[5],average;
    for(int i=0;i<5;i++){
        cout<<"enter "<<i+1<<"th  element for array ";
        cin>>k[i];
    }
    for(int i=0;i<5;i++){
        a
    }
}