#include<iostream>
#include<string>
using namespace std;

int main(){
    string x;
    cout<<"enter a name ";
    getline(cin,x);
     cout<<x<<"\n";
}