#include<iostream>
using namespace std;

void print(){
    string data,rollno;
    cout<<"enter name: ";
    cin>>data;
    cout<<"enter roll no: ";
    cin>>rollno;
    cout<<rollno<<" : "<<data<<"\n";
}


int main(){
    print();
    return 0;
    }