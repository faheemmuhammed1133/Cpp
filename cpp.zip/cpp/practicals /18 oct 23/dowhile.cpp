#include<iostream>
using namespace std;
int main(){
    int n=1;
    do{
        cout<<n<<endl;
        n++;
    }while(n<=10);
} 