//1 plane 
//2 suing c++ programme derive a number is odd or even using if else
//3 generate toss. wait 2 sec. show heads or tails random
#include <iostream> //for cout and cin
using namespace std;
int main() {
    cout << " myran zain: ";
    return 0;
}