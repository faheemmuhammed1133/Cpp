//
//  main.cpp
//  2023
//
//  Created by Muhammed Faheem on 21/09/23.
//

#include <iostream>
using namespace std;

int main() {
    int a,b;
    
    cout << "Hello, World!\n";
   
    cout<<"enter value for a & b";
    cin>>a>>b;
    
    int sum=a+b;
    cout<<"sum of "<<a <<" & "<<b<<" is "<<sum<<"\n";
    return 0;
}
