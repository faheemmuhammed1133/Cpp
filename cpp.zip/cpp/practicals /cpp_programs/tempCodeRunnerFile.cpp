double pi;
    pi=(22/7);
    cout<<pi<<endl;