#include<iostream>

using namespace std;

int main()
{
    cout<<"\n\n\tworld is large\n\n";
    return 0;

}