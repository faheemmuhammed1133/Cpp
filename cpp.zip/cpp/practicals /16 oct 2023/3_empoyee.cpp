#include<iostream>
using namespace std;
class Employee{
    public:
    int employee_number=1;
    float basic_salary=50000.00,net_salary,da;
    string employee_name;

};
