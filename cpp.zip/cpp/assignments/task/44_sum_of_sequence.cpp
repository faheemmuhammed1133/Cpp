#include <iostream>

double sumSeries(int n) {
    double sum = 0;
    for(int i = 1; i <= n; i++) {
        double fact = 1;
        for(int j = 1; j <= i; j++) {
            fact *= j;
        }
        sum += i / fact;
    }
    return sum;
}

int main() {
    int n;
    std::cout << "Enter the number of terms: ";
    std::cin >> n;
    std::cout << "The sum of the series is: " << sumSeries(n) << std::endl;
    return 0;
}
